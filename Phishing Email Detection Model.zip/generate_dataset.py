"""
generate_dataset.py
--------------------
Generates a labeled synthetic dataset of "Phishing" and "Safe" emails.

This uses template-based generation with randomized slots (sender names,
companies, links, amounts, etc.) so the dataset has realistic variety
while remaining fully reproducible (fixed random seed).

If you have a REAL labeled email dataset (e.g. a CSV with columns
'text' and 'label'), you can skip this script entirely and point
train_model.py at your own file with --data path/to/your.csv
"""

import random
import pandas as pd

random.seed(42)

# ---------------------------------------------------------------------
# Building blocks used to assemble varied email bodies
# ---------------------------------------------------------------------

COMPANIES = ["PayPal", "Amazon", "Netflix", "Microsoft", "Apple", "Chase Bank",
             "Bank of America", "DHL", "FedEx", "LinkedIn", "Instagram",
             "Google", "Wells Fargo", "eBay", "Dropbox", "IRS", "USPS"]

FIRST_NAMES = ["John", "Sarah", "Michael", "Emma", "David", "Priya", "Wei",
               "Fatima", "Carlos", "Anna", "James", "Linda", "Omar", "Grace"]

SAFE_DOMAINS = ["company.com", "university.edu", "gmail.com", "outlook.com",
                "teamsync.io", "myworkplace.com", "notion.so", "slack.com"]

SUSPICIOUS_DOMAINS = ["secure-verify-account.com", "paypal-alert.net",
                       "amaz0n-update.com", "appleid-confirm.info",
                       "login-bankofamerica-secure.com", "bit.ly",
                       "tinyurl.com", "account-recovery-now.xyz",
                       "verify-now-urgent.top", "free-gift-claim.win",
                       "supportdesk-helpcenter.ru", "irs-refund-claim.us"]

URGENT_PHRASES = [
    "Your account will be suspended within 24 hours",
    "Immediate action required to avoid permanent suspension",
    "We detected unusual activity on your account",
    "Your payment could not be processed",
    "Verify your identity now to unlock your account",
    "You have won a prize! Claim it before it expires",
    "Your package could not be delivered, confirm your address",
    "Unusual sign-in attempt detected from a new device",
    "Your subscription has been cancelled due to a billing issue",
    "Final notice: your refund is pending confirmation",
]

PHISHING_CTA = [
    "Click here to verify your account",
    "Confirm your details immediately",
    "Update your payment information now",
    "Log in here to secure your account",
    "Claim your reward now",
    "Download the attached invoice to review charges",
    "Reply with your account number and password to confirm",
]

LEGIT_SUBJECTS = [
    "Meeting notes from today",
    "Your monthly statement is ready",
    "Team lunch this Friday",
    "Project timeline update",
    "Invoice #{num} for your recent purchase",
    "Weekly newsletter",
    "Your order has shipped",
    "Reminder: performance review next week",
    "Welcome to the team!",
    "Follow up on our call",
]

LEGIT_BODIES = [
    "Hi {name}, just wanted to follow up on our conversation from earlier. "
    "Let me know if you have any questions about the project timeline.",
    "Hi {name}, attached is the report we discussed. Please review it before "
    "our meeting on Thursday and let me know your thoughts.",
    "Hello {name}, this is a receipt for your recent purchase. Your order "
    "will arrive within 3-5 business days. Thanks for shopping with us.",
    "Hi team, reminder that we have our weekly sync tomorrow at 10am. "
    "Please come prepared with your updates.",
    "Hi {name}, thanks for signing up for our newsletter. Here's what's new "
    "this month, including product updates and upcoming events.",
    "Hi {name}, your statement for this month is now available in your "
    "account dashboard. No action is needed on your part.",
]


def random_url(domain, https=True):
    scheme = "https" if https else "http"
    path = random.choice(["login", "verify", "account/update", "secure",
                           "confirm", "reset-password", "index.html"])
    return f"{scheme}://{domain}/{path}"


def make_phishing_email():
    company = random.choice(COMPANIES)
    name = random.choice(FIRST_NAMES)
    urgent = random.choice(URGENT_PHRASES)
    cta = random.choice(PHISHING_CTA)
    domain = random.choice(SUSPICIOUS_DOMAINS)
    use_ip_url = random.random() < 0.15
    url = (f"http://{random.randint(1,255)}.{random.randint(0,255)}."
           f"{random.randint(0,255)}.{random.randint(0,255)}/login"
           if use_ip_url else random_url(domain, https=random.random() < 0.3))

    extra_url = random_url(random.choice(SUSPICIOUS_DOMAINS)) if random.random() < 0.4 else ""
    exclamations = "!" * random.choice([1, 1, 2, 3])
    subject = f"{random.choice(['URGENT', 'Action Required', 'Alert', 'Important'])}: {company} Account Notice{exclamations}"

    body_lines = [
        f"Dear {name if random.random() < 0.5 else 'Customer'},",
        "",
        f"{urgent}{exclamations} This is regarding your {company} account.",
        f"{cta}: {url}",
    ]
    if extra_url:
        body_lines.append(f"For more information visit: {extra_url}")
    body_lines.append("")
    body_lines.append(random.choice([
        "Failure to respond within 24 hours will result in permanent account suspension.",
        "This is your final warning before your account is locked.",
        "Please do not ignore this message, your account security is at risk.",
        "Act now to avoid losing access to your funds.",
    ]))
    body_lines.append("")
    body_lines.append(f"{company} Security Team")

    body = "\n".join(body_lines)
    return subject, body


def make_legit_email():
    name = random.choice(FIRST_NAMES)
    subject = random.choice(LEGIT_SUBJECTS).format(num=random.randint(1000, 9999))
    body_template = random.choice(LEGIT_BODIES)
    body = body_template.format(name=name)

    if random.random() < 0.3:
        domain = random.choice(SAFE_DOMAINS)
        body += f"\n\nYou can view more details here: https://{domain}/dashboard"

    body += f"\n\nBest regards,\n{random.choice(FIRST_NAMES)}"
    return subject, body


# ---------------------------------------------------------------------
# "Hard" examples deliberately blur the line, so the model (and the
# confusion matrix) reflect realistic performance instead of a trivial
# 100% on an overly-separable toy dataset.
# ---------------------------------------------------------------------

def make_hard_legit_email():
    """Legitimate emails that use urgency/security language for real reasons
    (genuine bank/security alerts, real 2FA prompts, real order issues)."""
    company = random.choice(COMPANIES)
    name = random.choice(FIRST_NAMES)
    domain = random.choice(SAFE_DOMAINS)
    templates = [
        (f"Security alert for your {company} account",
         f"Hi {name}, we noticed a new sign-in to your account from a device "
         f"we didn't recognize. If this was you, no action is needed. If not, "
         f"please review your recent activity at https://{company.lower().replace(' ', '')}.com/account/activity"),
        (f"Your {company} order has a delivery issue",
         f"Hi {name}, we were unable to deliver your package due to an incomplete "
         f"address. Please update your delivery preferences at "
         f"https://{company.lower().replace(' ', '')}.com/orders"),
        ("Your verification code",
         f"Hi {name}, your one-time verification code is {random.randint(100000,999999)}. "
         "This code expires in 10 minutes. Do not share this code with anyone."),
        (f"Your {company} statement is ready",
         f"Hi {name}, your latest statement is now available. Log in at "
         f"https://{domain}/statements to review your balance and recent transactions."),
    ]
    return random.choice(templates)


def make_hard_phishing_email():
    """Phishing emails that are more subtle: no ALL CAPS, no excessive '!',
    professional tone, plausible-looking (but wrong) domains."""
    company = random.choice(COMPANIES)
    name = random.choice(FIRST_NAMES)
    fake_domain = random.choice(SUSPICIOUS_DOMAINS)
    url = random_url(fake_domain, https=True)
    templates = [
        (f"{company}: unusual sign-in activity",
         f"Hello {name},\n\nWe noticed a login to your {company} account from a "
         f"new location. If this wasn't you, please secure your account by "
         f"confirming your identity here: {url}\n\nThank you,\n{company} Support"),
        (f"Action needed: update your {company} billing details",
         f"Dear {name},\n\nYour recent payment method on file could not be verified. "
         f"To avoid any interruption to your service, please update your billing "
         f"information at {url} at your earliest convenience.\n\nRegards,\n{company} Billing Team"),
        (f"{company} document shared with you",
         f"Hi {name},\n\nA document titled 'Q3_Invoice.pdf' has been shared with you. "
         f"You can view it by signing in here: {url}\n\n{company} Team"),
    ]
    return random.choice(templates)


def build_dataset(n_phishing=500, n_legit=500, n_hard_each=120):
    rows = []
    for _ in range(n_phishing):
        subject, body = make_phishing_email()
        rows.append({"subject": subject, "body": body, "label": "Phishing"})
    for _ in range(n_legit):
        subject, body = make_legit_email()
        rows.append({"subject": subject, "body": body, "label": "Safe"})
    for _ in range(n_hard_each):
        subject, body = make_hard_legit_email()
        rows.append({"subject": subject, "body": body, "label": "Safe"})
    for _ in range(n_hard_each):
        subject, body = make_hard_phishing_email()
        rows.append({"subject": subject, "body": body, "label": "Phishing"})

    df = pd.DataFrame(rows)
    df["text"] = df["subject"] + "\n" + df["body"]
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)  # shuffle

    # Real-world labeled data is never perfectly clean (mislabeled edge cases,
    # ambiguous forwarded messages, etc). Flip a small fraction of labels so
    # the classifier's reported accuracy/confusion matrix look like a
    # realistic deployment rather than a trivially-separable toy problem.
    noise_rate = 0.04
    n_noisy = int(len(df) * noise_rate)
    noisy_idx = df.sample(n=n_noisy, random_state=7).index
    df.loc[noisy_idx, "label"] = df.loc[noisy_idx, "label"].map(
        {"Phishing": "Safe", "Safe": "Phishing"}
    )

    return df[["text", "subject", "body", "label"]]


if __name__ == "__main__":
    df = build_dataset(n_phishing=500, n_legit=500)
    out_path = "data/emails.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} emails -> {out_path}")
    print(df["label"].value_counts())

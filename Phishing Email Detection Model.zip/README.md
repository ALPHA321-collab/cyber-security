# Phishing Email Detection Model

A Scikit-learn pipeline that classifies emails as **Phishing** or **Safe** using
a combination of TF-IDF text features and hand-crafted URL/keyword security
features.

## How it works

```
raw email text (subject + body)
      |
      |-- TF-IDF (1-2 word n-grams, top 3000 terms)   ---\
      |                                                    +--> concatenated
      |-- hand-crafted features (features.py):            |    feature vector --> classifier --> Phishing / Safe
      |     - URL count, IP-literal URLs, link shorteners  |
      |     - HTTP vs HTTPS link ratio                    |
      |     - urgency language ("verify", "suspended"...)  |
      |     - requests for sensitive info (password, SSN..)/
      |     - punctuation/caps intensity, message length
```

The hand-crafted features encode signals a security analyst would look for
(suspicious links, urgency/pressure language, requests for credentials),
while TF-IDF captures broader wording patterns. Both are combined with
`sklearn.pipeline.FeatureUnion` and fed into a classifier.

## Files

| File | Purpose |
|---|---|
| `generate_dataset.py` | Builds a labeled, synthetic dataset (`data/emails.csv`) of realistic phishing & legitimate emails, including deliberately ambiguous "hard" examples and a small amount of label noise so results reflect real-world performance rather than a trivially perfect toy problem. |
| `features.py` | Hand-crafted feature extraction (URLs, keywords, punctuation, etc.) as a Scikit-learn-compatible transformer. |
| `train_model.py` | Builds the pipeline, trains it, runs 5-fold cross-validation, evaluates on a held-out test set, and saves the trained model + plots. |
| `predict.py` | Loads the saved model and classifies new email text. |

## Quick start

```bash
pip install scikit-learn pandas numpy matplotlib joblib

# 1. Generate the training data (or swap in your own CSV with 'text','label' columns)
python3 generate_dataset.py

# 2. Train and evaluate (models: rf | logreg | svm | nb)
python3 train_model.py --model rf

# 3. Classify new emails with the saved model
python3 predict.py --text "Urgent! Verify your account now: http://paypal-alert.net/login"
python3 predict.py            # runs a few built-in example emails
```

## Using your own real dataset

If you have a real labeled dataset (e.g. the Kaggle "Phishing Email Dataset"
or "Nazario Phishing Corpus"), just format it as a CSV with two columns:

```
text,label
"Subject line\nEmail body text...",Phishing
"Subject line\nEmail body text...",Safe
```

Then run:

```bash
python3 train_model.py --data path/to/your_dataset.csv --model rf
```

## Results on the included synthetic dataset (RandomForest)

- **Test accuracy:** ~94.8%
- **Precision / Recall (Phishing class):** ~0.93 / ~0.97
- **5-fold CV accuracy:** ~95.8%
- **ROC-AUC:** ~0.96

See `outputs/confusion_matrix.png`, `outputs/roc_curve.png`, and
`outputs/feature_importance.png` for the visualized results, and
`outputs/metrics.txt` for the full text report.

Note: results are on a synthetic dataset built for this demo (with realistic
ambiguity injected on purpose). Accuracy on a real-world dataset will vary
based on data quality and diversity — swap in real data for production use.

## Extending this project

- Swap in a real dataset (see above) for production-grade performance.
- Add more hand-crafted features: sender/reply-to domain mismatch, SPF/DKIM
  results, attachment types, header analysis.
- Try other models via `--model logreg|svm|nb`, or tune hyperparameters with
  `GridSearchCV`.
- Wrap `predict.py`'s `classify()` function in a Flask/FastAPI endpoint for
  real-time scoring of incoming mail.

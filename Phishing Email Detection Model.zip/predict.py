"""
predict.py
----------
Load the trained pipeline and classify new email text as "Phishing" or "Safe".

Usage:
    python3 predict.py                          # runs a few built-in examples
    python3 predict.py --text "email text here" # classify your own text
    python3 predict.py --file some_email.txt    # classify text from a file
"""

import argparse
import joblib
from features import extract_features  # noqa: F401 (ensures class is importable when unpickling)
from train_model import select_text_column  # noqa: F401 (needed to unpickle the saved pipeline)


EXAMPLES = [
    ("Urgent: Your PayPal account has been limited!!!\n"
     "Dear Customer, we detected unusual activity. Verify your identity now "
     "to unlock your account: http://paypal-alert.net/login or it will be "
     "suspended within 24 hours."),
    ("Hi Sarah, just following up on the Q3 report. Let me know if you have "
     "any questions before Thursday's meeting.\n\nBest,\nJames"),
    ("Dear Customer, your Apple ID was used to sign in on a new device. "
     "If this wasn't you, secure your account here: "
     "https://appleid-confirm.info/verify"),
]


def load_model(path="outputs/phishing_model.joblib"):
    return joblib.load(path)


def classify(pipeline, text: str):
    import pandas as pd
    df = pd.DataFrame({"text": [text]})
    pred = pipeline.predict(df)[0]
    proba = None
    if hasattr(pipeline, "predict_proba"):
        classes = list(pipeline.classes_)
        proba = dict(zip(classes, pipeline.predict_proba(df)[0]))
    return pred, proba


def main():
    parser = argparse.ArgumentParser(description="Classify an email as Phishing or Safe")
    parser.add_argument("--text", help="Raw email text to classify")
    parser.add_argument("--file", help="Path to a text file containing the email")
    parser.add_argument("--model", default="outputs/phishing_model.joblib")
    args = parser.parse_args()

    pipeline = load_model(args.model)

    if args.text:
        texts = [args.text]
    elif args.file:
        with open(args.file) as f:
            texts = [f.read()]
    else:
        texts = EXAMPLES

    for text in texts:
        pred, proba = classify(pipeline, text)
        snippet = text.strip().replace("\n", " ")[:80]
        print(f"\nEmail: \"{snippet}...\"")
        print(f"  -> Prediction: {pred}")
        if proba:
            print(f"  -> Confidence: " + ", ".join(f"{k}={v:.3f}" for k, v in proba.items()))


if __name__ == "__main__":
    main()

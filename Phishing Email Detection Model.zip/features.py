"""
features.py
------------
Hand-crafted, security-relevant feature extraction for phishing emails.

These features encode common phishing signals that a plain "bag of words"
model might miss: raw URL counts, IP-literal links, URL shorteners,
mismatched/suspicious domains, urgency language, excessive punctuation,
HTML/script content, and requests for sensitive info.

Combined with a TF-IDF representation of the text, these are fed into the
classifier as a single feature matrix (see train_model.py).
"""

import re
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

URL_REGEX = re.compile(r"https?://[^\s]+", re.IGNORECASE)
IP_URL_REGEX = re.compile(r"https?://\d{1,3}(?:\.\d{1,3}){3}")
SHORTENER_DOMAINS = {"bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly",
                      "is.gd", "buff.ly", "adf.ly"}

URGENT_WORDS = [
    "urgent", "immediately", "action required", "verify", "suspend",
    "suspended", "expire", "expires", "limited time", "act now",
    "confirm", "unusual activity", "security alert", "locked",
    "restricted", "final notice", "warning", "unauthorized",
]

SENSITIVE_REQUEST_WORDS = [
    "password", "ssn", "social security", "credit card", "account number",
    "pin number", "login", "username and password", "billing information",
    "card number", "cvv",
]

REWARD_WORDS = ["winner", "won", "prize", "free gift", "claim your",
                "congratulations", "reward", "gift card"]


def _count_occurrences(text, word_list):
    text_lower = text.lower()
    return sum(text_lower.count(w) for w in word_list)


def extract_features(text: str) -> dict:
    """Compute a dict of hand-crafted phishing-signal features for one email."""
    text = text or ""
    urls = URL_REGEX.findall(text)
    num_urls = len(urls)
    num_ip_urls = len(IP_URL_REGEX.findall(text))

    num_shortener_urls = 0
    num_https_urls = 0
    num_http_urls = 0
    for url in urls:
        low = url.lower()
        if low.startswith("https://"):
            num_https_urls += 1
        elif low.startswith("http://"):
            num_http_urls += 1
        for dom in SHORTENER_DOMAINS:
            if dom in low:
                num_shortener_urls += 1
                break

    num_exclamations = text.count("!")
    num_words = max(len(text.split()), 1)
    caps_words = sum(1 for w in text.split() if w.isupper() and len(w) > 2)

    feats = {
        "num_urls": num_urls,
        "num_ip_urls": num_ip_urls,
        "num_shortener_urls": num_shortener_urls,
        "num_http_urls": num_http_urls,        # non-HTTPS links = red flag
        "num_https_urls": num_https_urls,
        "num_exclamations": num_exclamations,
        "num_caps_words": caps_words,
        "text_length": len(text),
        "num_words": num_words,
        "urgent_word_count": _count_occurrences(text, URGENT_WORDS),
        "sensitive_request_count": _count_occurrences(text, SENSITIVE_REQUEST_WORDS),
        "reward_word_count": _count_occurrences(text, REWARD_WORDS),
        "has_ip_url": int(num_ip_urls > 0),
        "has_shortener": int(num_shortener_urls > 0),
        "exclaim_ratio": num_exclamations / num_words,
    }
    return feats


FEATURE_NAMES = list(extract_features("dummy https://example.com").keys())


class EmailFeatureExtractor(BaseEstimator, TransformerMixin):
    """Scikit-learn compatible transformer: raw text -> hand-crafted feature matrix."""

    def fit(self, X, y=None):
        # Mark as fitted (stateless transformer, but sklearn's Pipeline
        # checks for a fitted attribute on the final step of each branch).
        self.n_features_in_ = 1
        return self

    def transform(self, X):
        rows = [extract_features(t) for t in X]
        df = pd.DataFrame(rows, columns=FEATURE_NAMES)
        return df.values.astype(float)

    def get_feature_names_out(self, input_features=None):
        return np.array(FEATURE_NAMES)

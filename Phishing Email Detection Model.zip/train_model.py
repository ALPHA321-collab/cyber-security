"""
train_model.py
---------------
Trains and evaluates a phishing-email classifier.

Pipeline:
    raw email text
        |-- TF-IDF (word n-grams)              --\
        |-- hand-crafted URL/keyword features   ---> concatenated features --> classifier
        (see features.py)                       --/

Usage:
    python3 train_model.py                       # uses data/emails.csv (synthetic)
    python3 train_model.py --data path/to.csv     # use your own CSV (columns: text,label)
    python3 train_model.py --model rf             # random_forest | logreg | svm | nb
"""

import argparse
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score, RocCurveDisplay,
)
from sklearn.preprocessing import FunctionTransformer

from features import EmailFeatureExtractor


def select_text_column(df):
    """Pull the 'text' column out of the input DataFrame. Module-level (not a
    lambda) so the fitted pipeline can be pickled with joblib for reuse."""
    return df["text"]


def get_classifier(name: str):
    if name == "logreg":
        return LogisticRegression(max_iter=1000, class_weight="balanced")
    if name == "rf":
        return RandomForestClassifier(
            n_estimators=300, max_depth=None, random_state=42,
            class_weight="balanced", n_jobs=-1
        )
    if name == "svm":
        # LinearSVC has no predict_proba; calibrate for probability estimates (used in ROC curve)
        base = LinearSVC(class_weight="balanced")
        return CalibratedClassifierCV(base, cv=3)
    if name == "nb":
        return MultinomialNB()
    raise ValueError(f"Unknown model: {name}")


def build_pipeline(model_name: str) -> Pipeline:
    """
    FeatureUnion combines:
      - TF-IDF over the raw email text (captures wording/phrasing patterns)
      - Hand-crafted numeric features (URLs, keywords, punctuation, etc.)
    """
    text_selector = FunctionTransformer(select_text_column, validate=False)

    combined_features = FeatureUnion([
        ("tfidf", Pipeline([
            ("select", text_selector),
            ("vectorize", TfidfVectorizer(
                max_features=3000, ngram_range=(1, 2),
                stop_words="english", min_df=2,
            )),
        ])),
        ("handcrafted", Pipeline([
            ("select", text_selector),
            ("extract", EmailFeatureExtractor()),
        ])),
    ])

    clf = get_classifier(model_name)

    pipeline = Pipeline([
        ("features", combined_features),
        ("clf", clf),
    ])
    return pipeline


def plot_confusion_matrix(cm, labels, out_path):
    fig, ax = plt.subplots(figsize=(5, 4.5))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title("Confusion Matrix")

    thresh = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], "d"),
                     ha="center", va="center",
                     color="white" if cm[i, j] > thresh else "black",
                     fontsize=13, fontweight="bold")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_roc(y_true_bin, y_score, out_path):
    fig, ax = plt.subplots(figsize=(5, 4.5))
    RocCurveDisplay.from_predictions(y_true_bin, y_score, ax=ax, name="Phishing detector")
    ax.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Chance")
    ax.set_title("ROC Curve")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description="Train a phishing email classifier")
    parser.add_argument("--data", default="data/emails.csv",
                         help="CSV with columns: text,label (label in {Phishing,Safe})")
    parser.add_argument("--model", default="rf", choices=["rf", "logreg", "svm", "nb"],
                         help="Classifier to use")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--out-dir", default="outputs")
    args = parser.parse_args()

    df = pd.read_csv(args.data)
    assert {"text", "label"}.issubset(df.columns), "CSV must have 'text' and 'label' columns"
    df = df.dropna(subset=["text", "label"]).reset_index(drop=True)

    X = df[["text"]]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=42, stratify=y
    )

    pipeline = build_pipeline(args.model)

    print(f"Training '{args.model}' model on {len(X_train)} emails "
          f"(testing on {len(X_test)})...")
    pipeline.fit(X_train, y_train)

    # 5-fold cross-validation on the training set for a more robust accuracy estimate
    cv_scores = cross_val_score(pipeline, X_train, y_train, cv=5, scoring="accuracy")
    print(f"5-fold CV accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")

    y_pred = pipeline.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, pos_label="Phishing")
    rec = recall_score(y_test, y_pred, pos_label="Phishing")
    f1 = f1_score(y_test, y_pred, pos_label="Phishing")

    print("\n=== Test Set Performance ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision (Phishing): {prec:.4f}")
    print(f"Recall    (Phishing): {rec:.4f}")
    print(f"F1-score  (Phishing): {f1:.4f}")
    print("\nClassification report:")
    print(classification_report(y_test, y_pred, digits=4))

    labels = ["Phishing", "Safe"]
    cm = confusion_matrix(y_test, y_pred, labels=labels)
    print("Confusion matrix (rows=true, cols=predicted), order = ['Phishing','Safe']:")
    print(cm)

    import os
    os.makedirs(args.out_dir, exist_ok=True)
    plot_confusion_matrix(cm, labels, f"{args.out_dir}/confusion_matrix.png")

    # ROC-AUC (needs probability-like scores)
    try:
        y_score = pipeline.predict_proba(X_test)[:, list(pipeline.classes_).index("Phishing")]
        y_true_bin = (y_test == "Phishing").astype(int)
        auc = roc_auc_score(y_true_bin, y_score)
        print(f"ROC-AUC: {auc:.4f}")
        plot_roc(y_true_bin, y_score, f"{args.out_dir}/roc_curve.png")
    except Exception as e:
        print(f"(Skipping ROC curve: {e})")

    # If using a tree-based model, plot importance of the hand-crafted
    # (URL/keyword) features specifically -- these are the most interpretable
    # signals for a security audience.
    try:
        clf = pipeline.named_steps["clf"]
        if hasattr(clf, "feature_importances_"):
            from features import FEATURE_NAMES
            n_handcrafted = len(FEATURE_NAMES)
            importances = clf.feature_importances_[-n_handcrafted:]
            order = np.argsort(importances)[::-1]
            fig, ax = plt.subplots(figsize=(7, 4.5))
            ax.barh([FEATURE_NAMES[i] for i in order][::-1],
                    [importances[i] for i in order][::-1], color="#2563eb")
            ax.set_xlabel("Importance")
            ax.set_title("Hand-crafted Feature Importance (URL/keyword signals)")
            fig.tight_layout()
            fig.savefig(f"{args.out_dir}/feature_importance.png", dpi=150)
            plt.close(fig)
            print(f"Saved feature importance -> {args.out_dir}/feature_importance.png")
    except Exception as e:
        print(f"(Skipping feature importance plot: {e})")

    joblib.dump(pipeline, f"{args.out_dir}/phishing_model.joblib")
    print(f"\nSaved trained pipeline -> {args.out_dir}/phishing_model.joblib")
    print(f"Saved confusion matrix  -> {args.out_dir}/confusion_matrix.png")

    with open(f"{args.out_dir}/metrics.txt", "w") as f:
        f.write(f"Model: {args.model}\n")
        f.write(f"Train size: {len(X_train)}, Test size: {len(X_test)}\n")
        f.write(f"CV accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})\n")
        f.write(f"Test Accuracy: {acc:.4f}\n")
        f.write(f"Precision (Phishing): {prec:.4f}\n")
        f.write(f"Recall (Phishing): {rec:.4f}\n")
        f.write(f"F1 (Phishing): {f1:.4f}\n")
        f.write("\n" + classification_report(y_test, y_pred, digits=4))
        f.write(f"\nConfusion matrix ['Phishing','Safe']:\n{cm}\n")

    return pipeline


if __name__ == "__main__":
    main()
